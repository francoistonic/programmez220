﻿using System;

namespace aclerbois.sayhello.programmez
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Salut les lecteurs du magazine Programmez!");
        }
    }
}
