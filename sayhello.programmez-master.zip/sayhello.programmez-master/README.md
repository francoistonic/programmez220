# sayhello.programmez

Projet pour un article à paraitre / paru dans le magazine Programmez.

L'article explique comment créer un global tool avec .NET Core 2.1
