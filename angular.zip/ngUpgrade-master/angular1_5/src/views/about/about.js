app
  .component('about', {
    templateUrl: 'views/about/about.html',
    controller: 'aboutViewController as aboutViewCtrl'
  })
  .controller('aboutViewController', function() {
  });
