app
  .component('contact', {
    templateUrl: 'views/contact/contact.html',
    controller: 'contactViewController as contactViewCtrl'
  })
  .controller('contactViewController', function() {
  });
