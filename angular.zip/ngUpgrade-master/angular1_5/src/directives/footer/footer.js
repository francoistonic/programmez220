app
  .component('globalFooter', {
    templateUrl: 'directives/footer/footer.html'
  });

