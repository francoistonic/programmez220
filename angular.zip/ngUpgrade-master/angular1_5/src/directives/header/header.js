app
  .component('globalHeader', {
    templateUrl: 'directives/header/header.html'
  });

